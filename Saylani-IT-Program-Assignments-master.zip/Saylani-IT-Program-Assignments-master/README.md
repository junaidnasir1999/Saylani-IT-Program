# SAYLANI MASS IT PROGRAM 
# WEB AND MOBILE HYBRID DEVELOPMENT
## ASSIGNMENTS
All the tasks covers the Assignments of a  Web & Mobile Development consisting of the Programming Languages and tools used in Software Development .
